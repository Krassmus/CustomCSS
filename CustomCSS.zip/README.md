CustomCSS
=========

Stud.IP.plugin for customizing Stud.IP by typing CSS
